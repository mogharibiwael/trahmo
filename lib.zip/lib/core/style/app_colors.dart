

import 'package:flutter/material.dart';

class AppColors{
 static Color checkIconColor=Color(0xff27AE60);
 static Color textFieldColor= Color(0xffF2F2F2);
 static Color buttonColor= Color(0xff46a2b4);
}



