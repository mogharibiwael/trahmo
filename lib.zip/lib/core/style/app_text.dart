




class AppText {

  static String signUpText="Sign Up";
  static String signUpTextCapitalize="SIGN UP";
  static String loginTextCapitalize="LOGIN";
  static String nameFieldLabel="name";
  static String orSignUp="or sign up with social account";
  static String login="Login";
  static String forgotPassword="Forgot Password";
  static String forgotYourPassword="Forgot your Password?";

  static String contentForgotPasswordHint="Please, enter your email address. You will receive a link to create a new password via email.";


  static String emailFieldLabel="Email";
  static String send="SEND";
  static String passwordFieldLabel="password";
  static String alreadyHaveAccount="Already have an account?";
}