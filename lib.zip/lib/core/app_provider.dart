class AppProvider{
  static String baseUrl='http://192.168.113.241:5004';
  static String getState='$baseUrl/api/get_state';
  static String getStateByCategory='$baseUrl/api/get_state_by_category';
  static String sendTabraa='$baseUrl/api/send_tabraa';
  static String getCategoryState='$baseUrl/api/get_category_with_state';
}
